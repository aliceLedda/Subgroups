 tab<-read.table("dropbox/finaltable.txt")
 source("progs/xavierTime.R")
options(digits=10)
 rate<-8.4
 tab<-read.table("dropbox/swab.txt")

 for (i in 1:length(tab[,1])){
 tmp<-unlist(strsplit(as.character(tab[i,4]),"[[:punct:]]"))
 if(tmp[1]==3){base<-60
 }else{if(tmp[1]==4){base<-91
 }else{if(tmp[1]==5){base<-121
 }}}
 day<-base+as.numeric(tmp[2])
 #if(tmp[4] == "pm"){day<-day+0.5}
 toadd<-day/366
 date<-as.numeric(tmp[3])+toadd
 tab[i,7]<-date
 }
 
 Rename<-function(arg){
 parts<-unlist(strsplit(as.character(arg),"_"))
 one<-unlist(strsplit(parts[1],""))
 if (one[2]==0){
	if (one[3]==0){parts[1]<-gsub("T00","T",parts[1])}
	else{
	parts[1]<-gsub("T0","T",parts[1])}
	}

 

	two<-unlist(strsplit(parts[2],""))
	if (two[2]==0){
		new<-paste(two[1],"0",two[2],sep="")
	}else{new<-parts[2]}
	
newid<-paste(parts[1],new,sep="_")
 return(newid)

	 }
 
 Redate<-function(arg){
 tmp<-unlist(strsplit(as.character(arg),"[[:punct:]]"))
 if(tmp[1]==2){base<-31
 }else{if(tmp[1]==3){base<-60
 }else{if(tmp[1]==4){base<-91
 }else{if(tmp[1]==5){base<-121
 }}}}
 day<-base+as.numeric(tmp[2])
 #if(tmp[4] == "pm"){day<-day+0.5}
 toadd<-day/366
 date<-as.numeric(tmp[3])+toadd
 return(date)
 }
 
 tab[,7]<-sapply(1:length(tab[,4]),function(x){Redate(tab[x,4])})
 tab[,8]<-sapply(1:length(tab[,4]),function(x){RenameBack(tab[x,3])})
tree<-read.tree("/media/alice/B01F-858C/t126.phy_phyml_treeR.txt")
plot.phylo(tree)
> 

  tree2<-di2multi(tree,tol =  5e-08)
tree3<-drop.tip(tree2, "TW20" )
 
 
 tab<-read.table("datingTable.csv",sep=":",row.names=1,header=TRUE)
 
 tree<-read.tree("")
 
 foglie<-tree$tip.label
  
newtime<-matrix(nrow=length(foglie),ncol=3)
newtime[,1]<-foglie
newtime[,2]<-sapply(1:length(foglie),function(x){NameCut(foglie[x])})
#newtime[,2]<-sapply(1:length(foglie),function(x){sample(foglie[x])})
newtime[,3]<-as.numeric(unlist(sapply(1:length(foglie),function(x){Date(NameCut(foglie[x]))})))

#### function sample

sample<-function(name){
tmp<-unlist(strsplit(name,"[[:punct:]]"))
l<-nchar(tmp[1])
if(l==3){tmp[1]<-sub("T","T0",tmp[1])
}else{if(l==2){tmp[1]<-sub("T","T00",tmp[1])}}
s<-paste(tmp[1],tmp[2],sep="_")
return(s)}

#### function date

date<-function(name){
if(name=="TW20"){d<-2008
}else{
s<-sample(name)
d<-Date(s)}
return(d)}


####### function Date
Date<-function(name){
if(name=="TW20_NA"){d<-2008
}else{

d<-tab[tab[,8]==name,7]}
return(d)}



###function Rename
Rename<-function(arg){
 parts<-unlist(strsplit(as.character(arg),"_"))
 one<-unlist(strsplit(parts[1],""))
 if (one[2]==0){
	if (one[3]==0){parts[1]<-gsub("T00","T",parts[1])}
	else{
	parts[1]<-gsub("T0","T",parts[1])}
	}
	two<-unlist(strsplit(parts[2],""))
	if (two[2]==0){
		new<-paste(two[1],two[3],sep="")
	}else{new<-parts[2]}
	
newid<-paste(parts[1],new,sep="_")
 return(newid) }
 
 ####function RenameBack
 RenameBack<-function(arg){
 parts<-unlist(strsplit(as.character(arg),"_"))
if (nchar(parts[1])==2){
	parts[1]<-gsub("T","T00",parts[1])
}else{ if(nchar(parts[1])==3) {
parts[1]<-gsub("T","T0",parts[1])}
}
if(nchar(parts[2])==2){
two<-unlist(strsplit(parts[2],""))
new<-paste(two[1],"0",two[2],sep="")
}else{new<-parts[2]}
newid<-paste(parts[1],new,sep="_")
 return(newid) }


########## function NameCut
NameCut<-function(arg){
 parts<-unlist(strsplit(as.character(arg),"_"))
 newid<-paste(parts[1],parts[2],sep="_")
 return(newid)
 }



newtree<-timed(tree=tree, date=as.numeric(newtime[,3]),rate=rate)

treeR3<-newtree$tree

plot.phylo(treeR3)
 axisPhylo(side=1,root.time=2007.88479,backward=FALSE)
 pdf("t12TreeR3.pdf")
 plot.phylo(treeR3)
 axisPhylo(side=1,root.time=2007.88479,backward=FALSE)
 dev.off()

 write.tree(treeR3,file="t12TreeR3.tre")

 colorSub<-c("seagreen3", "dodgerblue4", "gold2", "firebrick","forestgreen","darkslategray4","darkolivegreen" )
 
 subgroup<-Ntree$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])

	
	
newtree$tree      newtree$record    newtree$rootdate  
> newtree$rootdate
[1] 2006.839009
 
 ######## group 4 #####################
 colorSub<-c( "green3","dodgerblue4","gold", "firebrick","aquamarine3", "hotpink","darkorange", "plum2" )

Ntree<-newtree$tree
 subgroup<-Ntree$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

date<-2007.281
date<-newtree$rootdate
plot.phylo(Ntree,show.tip.label=FALSE,)

plot.phylo(Ntree,tip.color=colSub, align.tip.label=TRUE,edge.width = 2, font = 2 )
 axisPhylo(side=1,root.time=date, backward=FALSE)
 
 plot.phylo(Ntree,tip.color=colSub, align.tip.label=TRUE,edge.width = 2, font = 2 )

axis(side=1,  at=c(0,0.22,0.47,0.72,0.97),labels=c("Apr 10","Jul 1", "Oct 1", "Jan 1 2008", "Apr 1"),lwd=2)

plot()
plot(c(20.55,27.5),c(5,5), col="firebrick2",type="l",lwd=5, xlim=c(15,35),ylim=c(0,6),axes=FALSE,xlab="",ylab="",ann=FALSE)
lines(c(15.5,20.5),c(0.15,0.15), col="firebrick2",type="l",lwd=5, lty=2)

lines(c(19.05,35.5),c(4,4), col="green3",type="l",lwd=5)
lines(c(15.5,19.55),c(0.05,0.05), col="green3",type="l",lwd=5, lty=2)

lines(c(20.5,25.45),c(2,2), col="gold",type="l",lwd=5)

lines(c(25.55,26.5),c(3,3), col="gold",type="l",lwd=5)

lines(c(17.5,18.95),c(4,4), col="dodgerblue2",type="l",lwd=5)

lines(c(19.05,19.45),c(1,1), col="dodgerblue2",type="l",lwd=5)

lines(c(19.55,20.45),c(5,5), col="dodgerblue2",type="l",lwd=5)

points(c(35,18,20,24,24),c(4,4,5,2,5), pch=8, cex=1.5, lwd=2 ,col="black")

axis(1, pos=(0), at=c(15,20,25,30,35),labels=c("March 15","March 20","March 25", "March 30", "Apr 5"))

axis(2, pos=15, at=c(0.1,1,2,3,4,5),labels=c("Other Ward","Bed 1","Bed 2", "Bed 3", "Bed 4","Bed 8"),las=2)

######### group 2 @#######
colorSub<-c( "cadetblue","dodgerblue4","steelblue", "firebrick","dodgerblue","gray","gray","gray","gray","gray","gray","gold","gray","gray","aquamarine4", "gray","gray","gray","red4","springgreen3","darkred", "purple", "cornflowerblue","goldenrod1","mediumorchid" )

Ntree<-newtree$tree
 subgroup<-Ntree$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=2006.154, backward=FALSE)
 axis(side=1,  at=c(0.35,0.85,1.35,1.85,2.35),labels=c("June 2006", "2007","June 2007","2008", "June 2008"),lwd=2)
 
############# group 5 ####################
tree<-read.tree("subgroups/group5.out.labelled_tree.newick")
Ntree<-read.tree("subgroups/group5.root2006.296.tre")
plot.phylo(Ntree)
 axisPhylo(side=1,root.time=2006.296, backward=FALSE)
colorSub<-c( "dodgerblue3", "firebrick2","gold","aquamarine4","springgreen3", "deeppink" , "forestgreen","orange","magenta", "darkorange")

 subgroup<-Ntree$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}
 plot.phylo(Ntree,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=2006.296, backward=FALSE)
  axis(side=1,  at=c(0.2,0.7,1.2,1.7,2.2),labels=c("June 2006", "2007","June 2007","2008", "June 2008"),lwd=2)

 
 
 ############# group 7 ####################
colorSub<-c( "dodgerblue4", "firebrick","gold","aquamarine4","springgreen3", "purple", "forestgreen","darkmagenta","mediumorchid", "deeppink", "darkorange")

 
 tree<-read.tree("subgroups/group7.out.labelled_tree.newick")
Ntree<-read.tree("subgroups/group7.root2007.716.tre")
treeD<-di2multi(tree, tol=0.0000002)
foglie<-treeD$tip.label
  
newtime<-matrix(nrow=length(foglie),ncol=3)
newtime[,1]<-foglie
newtime[,2]<-sapply(1:length(foglie),function(x){Rename(foglie[x])})
#newtime[,2]<-sapply(1:length(foglie),function(x){sample(foglie[x])})
newtime[,3]<-as.numeric(unlist(sapply(1:length(foglie),function(x){Date(NameCut(foglie[x]))})))[-54]

newtree<-timed(tree=treeD, date=as.numeric(newtime[,3]),rate=rate)

Ntree<-newtree$tree
date<-newtree$rootdate
plot.phylo(Ntree)
 axisPhylo(side=1,root.time=2007.693, backward=FALSE)
 
 Ntree<-read.tree("subgroups/group7.root2008.714.tre")


 subgroup<-Ntree$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree,tip.color=colSub, edge.width = 2, font = 2 , cex=0.5,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=2006.154, backward=FALSE)
 
 axis(side=1,  at=c(0,0.1,0.18,0.247),labels=c("March 1", "Apr 1", "May 1", "Jun 1"),lwd=2)


 write.tree(Ntree, file="subgroups/group7.root2008.174.tre")

  ############# group 4 ####################
 Ntree<-read.tree("subgroups/group4.root2006.294.tre")
plot.phylo(Ntree)
 axisPhylo(side=1,root.time=2006.294, backward=FALSE)

 colorSub<-c( "dodgerblue4", "firebrick","forestgreen","grey","deepskyblue", "sienna1","gold" ,"deeppink", "darkorange")

  subgroup<-Ntree$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])

 
plot.phylo(Ntree,tip.color=colSub, edge.width = 2, font = 2 , cex=0.5,align.tip.label=TRUE)
axis(side=1,  at=c(0.205,0.705,1.205,1.705,2.205),labels=c("June 2006", "2007","June 2007","2008", "June 2008"),lwd=2)

 