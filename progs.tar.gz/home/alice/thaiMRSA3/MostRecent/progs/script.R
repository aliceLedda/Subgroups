 library(ape)
 library(lattice)
 colorFun = colorRampPalette(c("white","chartreuse","green","forestgreen", "cadetblue", "blue", "darkblue", "violet", "purple","deeppink" ,"red"))

 tree<-read.nexus("RAxMLroot.tre")
 
 tab<-read.table("datingTable.csv",sep=":",row.names=1,header=TRUE)
tips<-tree$tip.label
tips<-tips[-278]

nametab<-matrix(nrow=length(tips),ncol=8)
nametab[,1]<-tips
nametab[,2]<-sapply(1:length(tips),function(x){unlist(strsplit(tips[x],split="_"))[1]})
nametab[,3]<-sapply(1:length(tips),function(x){unlist(strsplit(tips[x],split="_"))[2]})
nametab[,4]<-sapply(1:length(tips),function(x){unlist(strsplit(tips[x],split="_"))[3]})

nametab[,5]<-sapply(1:length(tips),function(x){paste(nametab[x,2],nametab[x,3],sep="_")})

nametab[,6]<-sapply(1:length(tips),function(x){substr(nametab[x,3],1,1)})
nametab[,7]<-sapply(1:length(tips),function(x){as.numeric(substr(nametab[x,3],2,3))})
nametab[,8]<-sapply(1:length(tips),function(x){as.numeric(substr(nametab[x,4],2,3))})

 write.table(nametab,file="nametab.txt",quote=FALSE,sep=";")

nametab<-read.table("nametab.txt",sep=";")

col<-matrix(nrow=length(unique(nametab[,4])),ncol=2)
 col[,1]<-unique(nametab[,4])
 col[,2]<-sapply(1:length(unique(nametab[,4])),function(x){length(nametab[nametab[,4]==unique(nametab[,4])[x],4])})
col[,3]<-sapply(1:length(unique(nametab[,4])),function(x){})
      [,1]  [,2]  
 [1,] "C26" "2"   
 [2,] "C05" "93"  
 [3,] "C07" "93"  
 [4,] "C13" "5"   
 [5,] "C01" "277" 
 [6,] "C02" "95"  
 [7,] "C08" "88"  
 [8,] "C06" "93"  
 [9,] "C03" "93"  
[10,] "C27" "2"   
[11,] "C09" "45"  
[12,] "C10" "6"   
[13,] "C25" "2"   
[14,] "C18" "5"   
[15,] "C22" "2"   
[16,] "C04" "93"  
[17,] "C17" "5"   
[18,] "C12" "5"   
[19,] "C16" "5"   
[20,] "C19" "5"   
[21,] "C29" "2"   
[22,] "C14" "5"   
[23,] "C21" "5"   
[24,] "C15" "5"   
[25,] "C11" "6"   
[26,] "C20" "5"   
[27,] "C28" "2"   
[28,] "C24" "2"   
[29,] "C23" "2"   
[30,] NA    "1020"
> 

col<-matrix(nrow=length(unique(nametab[,6])),ncol=2)
 col[,1]<-unique(nametab[,6])
 col[,2]<-as.numeric(sapply(1:length(unique(nametab[,6])),function(x){length(nametab[nametab[,6]==unique(nametab[,6])[x],6])}))
> col
  
 multiB<-(nametab[nametab[,6]!="N",])
 multiB<-multiB[-32,]

summary(multiB[,6])
 A  C  H  N  T  U  W 
26 35  1  0 62  2 11 

totalSeq<-summary(nametab[,2])
 
 barplot(totalSeq[totalSeq>1],las=2, main="N of sequences per patient")

barplot(totalSeq[totalSeq>1],las=2,log="y", main="N of sequences per patient") 

bodytable<-matrix(nrow=length(unique(multiB[,6])),ncol=length(unique(multiB[,2])))
rownames(bodytable)<-unique(multiB[,6])
colnames(bodytable)<-unique(multiB[,2])
for (i in 1:length(unique(multiB[,6]))){
	for (j in 1:length(unique(multiB[,2]))){
		bodytable[i,j]<-length(multiB[(multiB[,6]==unique(multiB[,6])[i])&(multiB[,2]==unique(multiB[,2])[j]),1])

	}
}

bodytable
  T126 T271 T301 T192 T327 T335 T270 T232 T330 T107 T102 T095 T099 T075 T014
C   17    1    0    0    0    0    0    0    0    0    0    0    0    0    0
A    4    1    0    0    0    1    0    0    0    0    0    0    0    1    1
W    1    1    0    0    0    0    0    0    0    0    0    0    1    0    0
T    0    3    1    1    1    0    0    2    1    0    1    1    0    0    0
U    0    0    0    0    0    0    1    0    0    1    0    0    0    0    0
H    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0
  T341 T087 T009 T056 T230 T234 T223 T249 T197 T156 T358 T065 T183 T194 T178
C    0    1    0    0    1    1    0    0    3    0    2    0    0    1    0
A    0    0    1    0    0    0    1    2    3    0    0    0    1    1    0
W    0    0    0    0    0    1    0    0    3    1    2    0    0    1    0
T    1    0    4    0    0    0    0    3    0    0    0    1    6    3    1
U    0    0    0    0    0    0    0    0    0    0    0    0    0    0    0
H    0    0    0    1    0    0    0    0    0    0    0    0    0    0    0
  T012 T159 T137 T322 T013 T028 T188 T071 T092 T104
C    0    2    1    1    0    1    1    2    0    0
A    7    1    0    0    1    0    0    0    0    0
W    0    0    0    0    0    0    0    0    0    0
T   22    0    6    0    0    0    0    0    3    1
U    0    0    0    0    0    0    0    0    0    0
H    0    0    0    0    0    0    0    0    0    0


levelplot(bodytable,col.regions=colorFun(500
),main="",xlab = "",ylab  = "",par.settings= 
list(axis.text=list(cex=3),fontsize=list(text=5)),colorkey = 
TRUE,scales=list(x=list(rot=90)))

bodytableBig<-matrix(ncol=(length(unique(nametab[,6]))+1),nrow=length(unique(nametab[,2])))
colnames(bodytableBig)<-c(as.character(unique(nametab[,6])),"sum")
rownames(bodytableBig)<-unique(nametab[,2])
for (i in 1:length(unique(nametab[,2]))){
	for (j in 1:length(unique(nametab[,6]))){
		bodytableBig[i,j]<-length(nametab[(nametab[,6]==unique(nametab[,6])[j])&(nametab[,2]==unique(nametab[,2])[i]),1])

	}
	bodytableBig[i,(j+1)]<-sum(bodytableBig[i,1:j])
}


levelplot(bodytableBig[bodytableBig[,8]>1,1:7],col.regions=colorFun(500
),main="",xlab = "",ylab  = "",par.settings= 
list(axis.text=list(cex=3),fontsize=list(text=5)),colorkey = 
TRUE,scales=list(x=list(rot=90)))

 small<-rownames(bodytableBig)
  small<-small[-1]
small<-small[-55]
levelplot(bodytableBig[small,1:7],col.regions=colorFun(500
),main="",xlab = "",ylab  = "",par.settings= 
list(axis.text=list(cex=1.5),fontsize=list(text=5)),colorkey = 
TRUE,scales=list(x=list(rot=90)))


File2<-read.table("subgroup2.txt")
Mat2<-matrix(nrow=length(File2[,1]),ncol=2,data=2)
Mat2[,1]<-as.character(File2[,1])

File3<-read.table("subgroup3.txt")
Mat3<-matrix(nrow=length(File3[,1]),ncol=2,data=3)
Mat3[,1]<-as.character(File3[,1])

File4<-read.table("subgroup4.txt")
Mat4<-matrix(nrow=length(File4[,1]),ncol=2,data=4)
Mat4[,1]<-as.character(File4[,1])

File5<-read.table("subgroup5.txt")
Mat5<-matrix(nrow=length(File5[,1]),ncol=2,data=5)
Mat5[,1]<-as.character(File5[,1])

File6<-read.table("subgroup6.txt")
Mat6<-matrix(nrow=length(File6[,1]),ncol=2,data=6)
Mat6[,1]<-as.character(File6[,1])

File7<-read.table("subgroup7.txt")
Mat7<-matrix(nrow=length(File7[,1]),ncol=2,data=7)
Mat7[,1]<-as.character(File7[,1])

groups<-rbind(Mat2,Mat3,Mat4,Mat5,Mat6,Mat7)
nametab[,9]<-unlist(sapply(1:length(nametab[,1]),function(x){as.numeric(groups[groups[,1]==nametab[x,1],2])}))

groups<-read.table("groups.txt",sep=";")

for (i in 1:length(nametab[,1])){
	if(nametab[i,1]== "T075_A02_C01"){nametab[i,9]<-1}else{
	nametab[i,9]<-groups[which(groups[,1]==as.character(nametab[i,1])),2]}
	nametab[i,10:16]<-tab[which(tab[,8]==as.character(nametab[i,5]))[1],1:7]
}

write.table(nametab,file="finaltable.txt",quote=FALSE,sep=";")


