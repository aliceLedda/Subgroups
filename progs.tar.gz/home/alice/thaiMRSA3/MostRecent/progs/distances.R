library(ape)
 library(phangorn)
 library(lattice)
 source("progs/xavierTime.R")
  Dist<-read.table("TreeD.txt",sep=";",header=TRUE,row.names=1)
tips<-rownames(Dist)
 options(digits=10)
  rate<-8.4 
  finaltab<-read.table("finaltable.txt",sep=";")
row.names(finaltab)<-finaltab[,1]
tips<-as.character(finaltab[,1])
#### T322_C02 is missing the date

all<-read.FASTA("ST239_Thai_Imperial_Tong_Harris_core_snp.aln")
Dist<-dist.dna(all,model="raw",variance=FALSE,pairwise.deletion=FALSE,as.matrix=TRUE)
DistSNP<-Dist*2456
dict<-read.table("Dict.csv")

distSNP<-DistSNP
Distrow<-row.names(distSNP)

Newrow<-rep(0,length(Distrow))
for (i in 1:length(Distrow)){
	if(Distrow[i]=="TW20"){Newrow[i]="TW20"
	}else{
	Newrow[i]<-as.character(dict[which(dict[,1]==Distrow[i]),2])
	}}
colnames(distSNP)<-Newrow
 rownames(distSNP)<-Newrow
write.table(distSNP,file="distSNP.txt",sep=";",quote=FALSE)
tips<-Newrow

distSNP<-read.table("distSNP.txt",sep=";",header=TRUE,row.names=1)
tips<-rownames(distSNP)


 min(finaltab[finaltab[,9]==6,16])

max(finaltab[finaltab[,9]==6,16])

mean(finaltab[finaltab[,9]==6,16])

min(finaltab[finaltab[,9]==6 & finaltab[,16]>2007.5,16])

mean(finaltab[finaltab[,9]==6 & finaltab[,16]>2007.5,16])


 min(finaltab[finaltab[,9]==5,16])

max(finaltab[finaltab[,9]==5,16])

mean(finaltab[finaltab[,9]==5,16])

min(finaltab[finaltab[,9]==5 & finaltab[,16]>2007.5,16])

mean(finaltab[finaltab[,9]==5 & finaltab[,16]>2007.5,16])

 min(finaltab[finaltab[,9]==4,16])

max(finaltab[finaltab[,9]==4,16])

mean(finaltab[finaltab[,9]==4,16])

min(finaltab[finaltab[,9]==4 & finaltab[,16]>2007.5,16])

mean(finaltab[finaltab[,9]==4 & finaltab[,16]>2007.5,16])


 min(finaltab[finaltab[,9]==3,16])

max(finaltab[finaltab[,9]==3,16])

mean(finaltab[finaltab[,9]==3,16])

min(finaltab[finaltab[,9]==3 & finaltab[,16]>2007.5,16])

mean(finaltab[finaltab[,9]==3 & finaltab[,16]>2007.5,16])


 min(finaltab[finaltab[,9]==2,16])

max(finaltab[finaltab[,9]==2,16])

mean(finaltab[finaltab[,9]==2,16])

min(finaltab[finaltab[,9]==2 & finaltab[,16]>2007.5,16])

mean(finaltab[finaltab[,9]==2 & finaltab[,16]>2007.5,16])


finaltab[finaltab[,9]==2,1]
#Dist2<-Dist[finaltab[finaltab[,9]==2,1],]

 Hdist<- hist(distSNP[upper.tri(distSNP,diag=FALSE)],breaks=seq(0,270,5))

 barplot(Hdist$density,col=c("grey50"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(Hdist$mids),las=2)
#

##############  group 2

 non2<-setdiff(tips,as.character(finaltab[finaltab[,9]==2,1]))

in2<-distSNP[as.character(finaltab[finaltab[,9]==2,1]),as.character(finaltab[finaltab[,9]==2,1])]
out2<-distSNP[as.character(finaltab[finaltab[,9]==2,1]),non2]

HistIn2<-hist(in2[upper.tri(in2,diag=FALSE)],breaks=seq(0,270,10))

HistOut2<-hist(as.matrix(out2),breaks=seq(0,270,10))

HistMat<-matrix(nrow=12,ncol=length(HistIn2$counts))
HistMat[1,]<-HistIn2$density
 HistMat[2,]<-HistOut2$density

 pdf("Group2Dist.pdf")

barplot(HistMat[1:2,],beside=TRUE,col=c("dodgerblue3","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 2")
legend("topright",c("within","between"),fill=c("dodgerblue2","grey80"))

mean(in2[upper.tri(in2,diag=FALSE)])

ks.test(HistMat2[1,],HistMat2[2,],alternative="two.sided")




############group 3


 non3<-setdiff(tips,as.character(finaltab[finaltab[,9]==3,1]))

in3<-distSNP[as.character(finaltab[finaltab[,9]==3,1]),as.character(finaltab[finaltab[,9]==3,1])]
out3<-distSNP[as.character(finaltab[finaltab[,9]==3,1]),non3]

HistIn3<-hist(in3[upper.tri(in3,diag=FALSE)],breaks=seq(0,270,10))

HistOut3<-hist(as.matrix(out3),breaks=seq(0,270,10))

HistMat[3,]<-HistIn3$density
 HistMat[4,]<-HistOut3$density

barplot(HistMat[3:4,],beside=TRUE,col=c("forestgreen","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 3")
legend("topright",c("within","between"),fill=c("forestgreen","grey80"))

mean(in3[upper.tri(in3,diag=FALSE)])

ks.test(HistMat2[1,],HistMat2[2,],alternative="two.sided")

 barplot(HistMat[1:4,],beside=TRUE,col=c("dodgerblue3","grey60","forestgreen","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 2")


############group 4


 non4<-setdiff(tips,as.character(finaltab[finaltab[,9]==4,1]))

in4<-distSNP[as.character(finaltab[finaltab[,9]==4,1]),as.character(finaltab[finaltab[,9]==4,1])]
out4<-distSNP[as.character(finaltab[finaltab[,9]==4,1]),non4]

HistIn4<-hist(in4[upper.tri(in4,diag=FALSE)],breaks=seq(0,270,10))

HistOut4<-hist(as.matrix(out4),breaks=seq(0,270,10))

HistMat[5,]<-HistIn4$density
 HistMat[6,]<-HistOut4$density

barplot(HistMat[5:6,],beside=TRUE,col=c("magenta4","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group4")
legend("topright",c("within","between"),fill=c("magenta4","grey80"))

mean(in2[upper.tri(in2,diag=FALSE)])

ks.test(HistMat2[1,],HistMat2[2,],alternative="two.sided")

 barplot(HistMat[1:4,],beside=TRUE,col=c("dodgerblue3","grey60","forestgreen","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 5")


############group 5
 non5<-setdiff(tips,as.character(finaltab[finaltab[,9]==5,1]))

in5<-distSNP[as.character(finaltab[finaltab[,9]==5,1]),as.character(finaltab[finaltab[,9]==5,1])]
out5<-distSNP[as.character(finaltab[finaltab[,9]==5,1]),non5]

HistIn5<-hist(in5[upper.tri(in5,diag=FALSE)],breaks=seq(0,270,10))

HistOut5<-hist(as.matrix(out5),breaks=seq(0,270,10))

HistMat[7,]<-HistIn5$density
 HistMat[8,]<-HistOut5$density

barplot(HistMat[7:8,],beside=TRUE,col=c("darkorange","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group5")
legend("topright",c("within","between"),fill=c("darkorange","grey80"))

mean(in2[upper.tri(in2,diag=FALSE)])

ks.test(HistMat2[1,],HistMat2[2,],alternative="two.sided")

 barplot(HistMat[1:4,],beside=TRUE,col=c("dodgerblue3","grey60","forestgreen","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 5")




############group 6
 non6<-setdiff(tips,as.character(finaltab[finaltab[,9]==6,1]))

in6<-distSNP[as.character(finaltab[finaltab[,9]==6,1]),as.character(finaltab[finaltab[,9]==6,1])]
out6<-distSNP[as.character(finaltab[finaltab[,9]==6,1]),non6]

HistIn6<-hist(in6[upper.tri(in6,diag=FALSE)],breaks=seq(0,270,10))

HistOut6<-hist(as.matrix(out6),breaks=seq(0,270,10))

HistMat[9,]<-HistIn6$density
 HistMat[10,]<-HistOut6$density

barplot(HistMat[9:10,],beside=TRUE,col=c("deeppink","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group6")
legend("topright",c("within","between"),fill=c("deeppink","grey80"))

mean(in2[upper.tri(in2,diag=FALSE)])

ks.test(HistMat2[1,],HistMat2[2,],alternative="two.sided")

 barplot(HistMat[1:4,],beside=TRUE,col=c("dodgerblue3","grey60","forestgreen","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 2")

############group 7
 non7<-setdiff(tips,as.character(finaltab[finaltab[,9]==7,1]))

in7<-distSNP[as.character(finaltab[finaltab[,9]==7,1]),as.character(finaltab[finaltab[,9]==7,1])]
out7<-distSNP[as.character(finaltab[finaltab[,9]==7,1]),non7]

HistIn7<-hist(in7[upper.tri(in7,diag=FALSE)],breaks=seq(0,270,10))

HistOut7<-hist(as.matrix(out7),breaks=seq(0,270,10))

HistMat[11,]<-HistIn7$density
 HistMat[12,]<-HistOut7$density

barplot(HistMat[11:12,],beside=TRUE,col=c("gold","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group6")
legend("topright",c("within","between"),fill=c("gold","grey80"))

mean(in2[upper.tri(in2,diag=FALSE)])

ks.test(HistMat2[1,],HistMat2[2,],alternative="two.sided")

 barplot(HistMat[1:4,],beside=TRUE,col=c("dodgerblue3","grey60","forestgreen","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2,main="Group 2")


barplot(HistMat[1:2,],beside=TRUE,col=c("dodgerblue3","grey80"),ylab="abundance",names.arg=round(HistIn2$mids),xaxt='n')
barplot(HistMat[3:4,],beside=TRUE,col=c("forestgreen","grey80"),ylab="abundance",names.arg=round(HistIn2$mids),xaxt='n')
barplot(HistMat[5:6,],beside=TRUE,col=c("magenta4","grey80"),ylab="abundance",names.arg=round(HistIn2$mids),xaxt='n')
barplot(HistMat[7:8,],beside=TRUE,col=c("darkorange","grey80"),ylab="abundance",names.arg=round(HistIn2$mids),xaxt='n')
barplot(HistMat[9:10,],beside=TRUE,col=c("deeppink","grey80"),ylab="abundance",names.arg=round(HistIn2$mids),xaxt='n')
barplot(HistMat[11:12,],beside=TRUE,col=c("gold","grey80"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=round(HistIn2$mids),las=2)


###########################################################################
########################################################################



plot()
plot(c(20.55,27.5),c(5,5), col="firebrick2",type="l",lwd=5, xlim=c(15,35),ylim=c(0,6),axes=FALSE,xlab="",ylab="",ann=FALSE)
lines(c(15.5,20.5),c(0.15,0.15), col="firebrick2",type="l",lwd=5, lty=2)

lines(c(19.05,35.5),c(4,4), col="green3",type="l",lwd=5)
lines(c(15.5,19.55),c(0.05,0.05), col="green3",type="l",lwd=5, lty=2)

lines(c(20.5,25.45),c(2,2), col="gold",type="l",lwd=5)

lines(c(25.55,26.5),c(3,3), col="gold",type="l",lwd=5)

lines(c(17.5,18.95),c(4,4), col="dodgerblue2",type="l",lwd=5)

lines(c(19.05,19.45),c(1,1), col="dodgerblue2",type="l",lwd=5)

lines(c(19.55,20.45),c(5,5), col="dodgerblue2",type="l",lwd=5)

points(c(35,18,20,24,24),c(4,4,5,2,5), pch=8, cex=1.5, lwd=2 ,col="black")

axis(1, pos=(0), at=c(15,20,25,30,35),labels=c("March 15","March 20","March 25", "March 30", "Apr 5"))

axis(2, pos=15, at=c(0.1,1,2,3,4,5),labels=c("Other Ward","Bed 1","Bed 2", "Bed 3", "Bed 4","Bed 8"),las=2)


samples6<-finaltab[finaltab[,9]==6,]

unique(samples6[,2])

dating<-read.table("datingTable.csv",sep=",")

all6<-rep(0,9)
for (i in 1:length(unique(samples6[,2]))){
all6<-rbind(all6,dating[dating[,2]==as.character(unique(samples6[,2])[i]),])}
all6<-all6[-1,]

todra6<-matrix(nrow=length(all6[,1]),ncol=3)

	todra6[,1]<-as.character(all6[,9])
	todra6[,3]<-as.character(all6[,8])
	mrsa<-grep("MRSA",as.character(all6[,7]))
	ax<-grep("Axilla",as.character(all6[,6]))
	todra6[ax,2]<-5
	todra6[intersect(ax,mrsa),2]<-18
	nose<-grep("Nasal",as.character(all6[,6]))
	todra6[nose,2]<-1
	todra6[intersect(nose,mrsa),2]<-19
	wound<-grep("Wound",as.character(all6[,6]))
	todra6[wound,2]<-3
	todra6[intersect(wound,mrsa),2]<-8
	Th<-grep("Throat",as.character(all6[,6]))
	todra6[Th,2]<-2
	todra6[intersect(Th,mrsa),2]<-17
	Tr<-grep("Tracheal",as.character(all6[,6]))
	todra6[Tr,2]<-0
	todra6[intersect(Tr,mrsa),2]<-15
	rest<-c(grep("Urine",as.character(all6[,6])))
	todra6[rest,2]<-4
	todra6[intersect(rest,mrsa),2]<-13


