 TooManyTimes<-read.table("/home/alice/thaiMRSA3/datingTable.txt")
allInfo<-read.csv("/home/alice/thaiMRSA3/dropbox/patient_demographics.info..csv",sep=";")
 Dist<-read.table("/home/alice/thaiMRSA3/subgroups/TreeD.txt",sep=";",header=TRUE,row.names=1)

existing<-rownames(Dist)


reTimes<-matrix(nrow=1,ncol=8,data=0)
for (i in 2:length(existing)){
	name<-existing[i]
	parts<-unlist(strsplit(name,"_"))
	REname<-paste(parts[1],parts[2],sep="_")
	reTimes<-rbind(reTimes,allTimes[which(allTimes[,8]==REname),])
}
allTimes<-reTimes
e riparti dallinizio... sperando che vada meglio...

pat<-unique(allTimes[,1])
smallTimes<-matrix(nrow=1,ncol=8,data=0)
for (i in 1:length(pat)){
	subT<-allTimes[allTimes[,1]==pat[i],]
	minT<-min(subT[,7])
	saveT<-subT[subT[,7]==minT,]
	smallTimes<-rbind(smallTimes,saveT)
}
smallTimes<-smallTimes[-1,]

oldSmallTimes<-smallTimes
smallTimes<-unique(oldSmallTimes)
#Stimes<-
#tosave<-smallTimes[match(allInfo[,1],smallTimes[,1]),1]

#Stimes<-(smallTimes[smallTimes[,1]])

for (i in 3:length(smallTimes[,1])){
	if (is.na(match(smallTimes[i,1],allInfo[,1]))){
		smallTimes[i,9]<-0
smallTimes[i,10]<-0
smallTimes[i,11]<-0
smallTimes[i,12]<-0
smallTimes[i,13]<-0
	}
	else{

	smallTimes[i,9]<-as.character(allInfo[which(allInfo[,1]==smallTimes[i,1]),5])
smallTimes[i,10]<-as.character(allInfo[allInfo[,1]==smallTimes[i,1],3])
smallTimes[i,11]<-as.character(allInfo[allInfo[,1]==smallTimes[i,1],4])
smallTimes[i,12]<-as.character(allInfo[allInfo[,1]==smallTimes[i,1],6])
smallTimes[i,13]<-paste(smallTimes[i,8],"C01",sep="_")
}
}

Stimes<-smallTimes[smallTimes[,12]!=0,]

Stimes<-Stimes[-1,]

 Dist<-read.table("/home/alice/thaiMRSA3/subgroups/TreeD.txt",sep=";",header=TRUE,row.names=1)
found<-na.omit(match(Stimes[,13],rownames(Dist)))

SubDist<-Dist[found[1:65],found[1:65]]

ward<-Stimes[Stimes[,9]=="ward start",13]
hosp<-Stimes[Stimes[,9]=="hosp else",13]
home<-Stimes[Stimes[,9]=="direct",13]

DistWard<-SubDist[ward,ward]
DistHosp<-SubDist[hosp,hosp]
DistHome<-SubDist[home,home]


length(rownames(DistWard))
[1] 9
 mean(as.dist(DistWard))  
201.2692
mean(as.dist(DistHosp))
214.3874
length(rownames(DistHosp))
37
 mean(as.dist(DistHome))
[1] 279.8007
 length(rownames(DistHome))
[1] 19

HistHome<-hist(as.dist(DistHome),breaks=45)

HistHosp<-hist(as.dist(DistHosp),breaks=44)

HistWard<-hist(as.dist(DistWard),breaks=40)

HistMatrix<-matrix(nrow=3,ncol=length(HistHome$counts))
HistMatrix[1,]<-HistHome$density
 HistMatrix[2,]<-c(HistHosp$density,0)
 HistMatrix[3,]<-c(HistWard$density,0,0,0,0,0)

barplot(HistMatrix,beside=TRUE,col=c("gold","firebrick","forestgreen"),xlab="genetic distance (SNPs)",ylab="abundance",names.arg=HistHome$mids)
legend("topright",c("home","hospital","ward"),fill=c("gold","firebrick","forestgreen"))
