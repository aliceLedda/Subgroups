library(ape)
library(lattice)
source("progs/xavierTime.R")

colorFun = colorRampPalette(c("white","chartreuse","green","forestgreen", "cadetblue", "blue", "darkblue", "violet", "purple","deeppink" ,"red"))
colortreeH<-c("deeppink", "gold","blue","darkblue", "cadetblue","chartreuse", "black", "chocolate", "chartreuse4","coral", "violet","cornflowerblue","cyan", "darkgoldenrod","black", "black", "darkgreen", "darkmagenta", "darkorange", "firebrick1")
colortree<-c("deeppink", "black", "gold","blue","darkblue", "cadetblue","chartreuse", "black", "chocolate", "chartreuse4","coral", "violet","cornflowerblue","cyan", "darkgoldenrod","black", "black", "darkgreen", "darkmagenta", "darkorange", "firebrick1","burlywood1")

tree<-read.tree("phyml-cfml.out.labelled_tree.newick")

#if the tree$edge.length is in units of mutations per genome, I have to multiply by the genome length 
#in thiis staph case 2902621
#newtree<-tree
#newtree$edge.length<-tree$edge.length*2902621

#the tree has also to be rooted
#if it isn't
#library(phangorn)
#Newtree<-midpoint(newtree)
#tree<-Newtree

#the rate has to be per GENOME per year. From pubblications (which?) 8.4
rate<-8.4

time<-read.table("newdate.txt")

tree<-root(oldtree, c("C00017272","C00021331"))

newtime<-matrix(nrow=length(tree$tip),ncol=3)
for(i in 1:length(tree$tip)){
newtime[i,]<-as.matrix(time[as.character(time[,1])==tree$tip[i],1:3])}


newtree<-timed(tree=tree, date=as.numeric(newtime[,3]),rate=rate)

Ntree<-newtree$tree
leaves<-c("C00017039","C00017244","C00021336","C00017164","C00028623","C00021330","C00017335","C00017158","C00017159","C00021325")
ShortTree<-drop.tip(Ntree,tip=leaves)


leaves<-c("C00017039","C00017244","C00021336","C00017164","C00028623","C00021330","C00017335","C00017158","C00017159","C00021325")
ShortTree<-drop.tip(oldtree,tip=leaves)
newtime<-matrix(nrow=length(ShortTree$tip),ncol=3)
for(i in 1:length(ShortTree$tip)){
strain<-unlist(strsplit(ShortTree$tip[i],"-"))[1]
newtime[i,]<-as.matrix(time[as.character(time[,1])==strain,1:3])}



newtree<-timed(tree=ShortTree, date=as.numeric(newtime[,3]),rate=rate)

