#!/usr/bin/perl
use strict;

my @samples=("S002","S007","S021","S024","S025","S026","S038","S039","S040","S042","S071","S078","S081","S085","S087", "S093","S097","S102","S106","S130","T009","T010","T012","T013","T014","T020","T021","T028","T035","T040",
"T056","T059","T065","T069","T071","T073","T075","T077","T087","T092","T095","T099","T102","T104","T105",
"T107","T126","T137","T156","T159","T178","T182","T183","T188","T192","T194","T197","T223","T225","T230","T232","T234","T241","T249","T270","T271","T301","T303","T322","T327","T330","T335","T341","T353","T358");

open (FILE, "/home/alice/thaiMRSA3/dropbox/patient_demographics.csv") or die "not found";
my $title=<FILE>;
my @file=<FILE>;
close FILE;

open (OUT, ">/home/alice/thaiMRSA3/MostRecent/patientDemo.csv")or die "not found2";
print OUT $title;
foreach my $line (@file){
	#print $line;
	for (my $i=0;$i<scalar(@samples);$i++){
		#print $samples[$i],"\t";
		if ($line=~m/^$samples[$i]/gi){
			print $samples[$i],"\n";
			print OUT $line;
			splice @samples,$i,1;
		}
	}
}
print "sobran\t",(join ("\t",@samples)),"\n";
close OUT;