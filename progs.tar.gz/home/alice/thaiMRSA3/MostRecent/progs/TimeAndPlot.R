 library(ape)
 library(phangorn)
 library(lattice)
 source("progs/xavierTime.R")
 options(digits=10)
  rate<-8.4 
  finaltab<-read.table("finaltable.txt",sep=";")
row.names(finaltab)<-finaltab[,1]

############## group 6 ########################
 tree6<-read.tree("treeOUT/group6.out.labelled_tree.newick")
#dating
plot.phylo(tree6)
 treeT<-tree6
 tree6<-treeT
tree6$edge.length<-treeT$edge.length*3043212
tips<-tree6$tip.label

totime<-matrix(nrow=length(tips),ncol=2)
totime[,1]<-tips
totime[,2]<-as.numeric(sapply(1:length(tips),function(x){finaltab[tips[x],16]}))

newtree6<-timed(tree=tree6, date=as.numeric(totime[,2]),rate=rate)

shortTree<-drop.tip(tree6,c("T059_N02_C02","S085_N01_C01"))

tree6<-shortTree
### redo al the dating 
Ntree6<-newtree6$tree

colorSub<-c( "green3","dodgerblue4", "aquamarine3","firebrick", "hotpink","darkorange","gold"  )
colorSub<-c("darkorange","green3","hotpink","aquamarine3","dodgerblue4","firebrick","gold" )

 subgroup<-Ntree6$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

date<-2006.63
plot.phylo(Ntree6,tip.color=colSub, align.tip.label=TRUE,edge.width = 2, font = 2 )
 axisPhylo(side=1,root.time=date, backward=FALSE)

plot.phylo(Ntree6,tip.color=colSub, align.tip.label=TRUE,edge.width = 2, font = 2 )
axis(side=1,  at=c(-0.07,0.37,0.87,1.37,1.87),labels=c("June 2006","Jan 2007","June 2007","Jan 2008","June 2008"),lwd=2)


################ group 5 #####################
tree5<-read.tree("treeOUT/group5.out.labelled_tree.newick")
#dating
plot.phylo(tree5)

shortTree<-drop.tip(tree5,"T099_N07_C02")
tree5<-shortTree
tree5$edge.length<-shortTree$edge.length*3043212
tips<-tree5$tip.label

totime<-matrix(nrow=length(tips),ncol=2)
totime[,1]<-tips
totime[,2]<-as.numeric(sapply(1:length(tips),function(x){finaltab[tips[x],16]}))

newtree5<-timed(tree=tree5, date=as.numeric(totime[,2]),rate=rate)

write.tree(newtree5$tree, file="group5S.root2001.06.tre")

Ntree5<-newtree5$tree
rootDate<-2001.06

colorSub<-c( "gold", "firebrick2","dodgerblue4","aquamarine4","springgreen3", "deeppink" , "forestgreen","orange","plum2", "darkorange")

 subgroup<-Ntree5$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree5,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=rootDate, backward=FALSE)
 
plot.phylo(Ntree5,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
axis(side=1,  at=c(-0.3,0.95,2.95,4.95,6.95,8.95),label=c("2001","2002","2004","2006","2008","2010"),lwd=2)


############# group 2 #############################

tree2<-read.tree("treeOUT/group2.out.labelled_tree.newick")
#dating
plot.phylo(tree2)

shortTree<-drop.tip(tree2,"TW20.dna")
tree2<-shortTree
tree2$edge.length<-shortTree$edge.length*3043212
tips<-tree2$tip.label

totime<-matrix(nrow=length(tips),ncol=2)
totime[,1]<-tips
totime[,2]<-as.numeric(sapply(1:length(tips),function(x){finaltab[tips[x],16]}))

newtree2<-timed(tree=tree2, date=as.numeric(totime[,2]),rate=rate)
rootDate<-newtree2$rootdate
Ntree2<-newtree2$tree

colorSub<-c( "cyan2","lightgreen","khaki", "lightgoldenrod","grey30", "grey50","lightgrey","aquamarine4","springgreen3", "deeppink" , "forestgreen","orange","plum2", "darkorange","gold", "firebrick2","dodgerblue4", "lightpink", "mistyrose3","lightseagreen","lightsalmon","mediumorchid","mediumpurple4","olivedrab2", "grey60")

 subgroup<-Ntree2$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree2,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=rootDate, backward=FALSE)

################## Partial ##################################


remove<-c("S002_N01_C01","S106_N01_C01", "S078_N01_C01", "T040_N01_C01", "S081_N01_C01","S024_N01_C01", "S021_N01_C01", "S039_N01_C01", "S042_N01_C01", "T014_A01_C01", "T234_W02_C01", "T230_C02_C01", "T341_T01_C01", "S026_N01_C01", "S097_N01_C01", "S025_N01_C01","TW20.dna")
   

shortTree<-drop.tip(tree2,remove)
tree2<-shortTree
tree2$edge.length<-shortTree$edge.length*3043212
tips<-tree2$tip.label

totime<-matrix(nrow=length(tips),ncol=2)
totime[,1]<-tips
totime[,2]<-as.numeric(sapply(1:length(tips),function(x){finaltab[tips[x],16]}))

newtree2<-timed(tree=tree2, date=as.numeric(totime[,2]),rate=rate)
rootDate<-newtree2$rootdate
Ntree2<-newtree2$tree


colorSub<-c(  "forestgreen","orange","plum2", "darkorange","gold", "firebrick2","dodgerblue4", "lightpink", "mistyrose3","lightseagreen","lightsalmon")

 subgroup<-Ntree2$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree2,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=rootDate, backward=FALSE)




############# group 4 #############################

tree4<-read.tree("treeOUT/group4.out.labelled_tree.newick")
#dating
plot.phylo(tree4)

shortTree<-drop.tip(tree4,"TW20.dna")
tree4<-shortTree
tree4$edge.length<-shortTree$edge.length*3043212
tips<-tree4$tip.label

totime<-matrix(nrow=length(tips),ncol=2)
totime[,1]<-tips
totime[,2]<-as.numeric(sapply(1:length(tips),function(x){finaltab[tips[x],16]}))

newtree4<-timed(tree=tree4, date=as.numeric(totime[,2]),rate=rate)
rootDate<-newtree4$rootdate
Ntree4<-newtree4$tree

colorSub<-c( "lightgreen","dodgerblue4", "deeppink" , "forestgreen","orange", "gold", "firebrick2","dodgerblue4", "lightpink", "mistyrose3","lightseagreen","lightsalmon","mediumorchid","mediumpurple4","olivedrab2", "grey60")

 subgroup<-Ntree4$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree2,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=rootDate, backward=FALSE)

plot.phylo(Ntree2,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
axis(side=1,  at=c(0.13,0.37,0.63,0.87,1.11),label=c("Apr2007","July2007","Oct2007","Jan2008","Apr2008"),lwd=2) 


##################### group 4 detail ##########################
remove<-c("TW20.dna","T028_C02_C01","S007_N01_C01" ,"T188_N03_C04", "T188_N02_C01" ,"T188_N02_C05" ,
	"T188_N03_C08" ,"T188_N02_C08", "T188_N02_C06","T188_N03_C09" ,"T188_C01_C01",
	 "T188_N03_C05", "T188_N02_C04" ,"T188_N02_C03", "T188_N03_C06", "T188_N02_C02", 
	 "T188_N03_C02", "T188_N03_C03", "T188_N03_C07","T188_N03_C01" ,"T188_N02_C07" ,"T188_N01_C01" )


shortTree<-drop.tip(tree4,remove)
tree4S<-shortTree
tree4S$edge.length<-shortTree$edge.length*3043212
tips<-tree4S$tip.label

totime<-matrix(nrow=length(tips),ncol=2)
totime[,1]<-tips
totime[,2]<-as.numeric(sapply(1:length(tips),function(x){finaltab[tips[x],16]}))

newtree4S<-timed(tree=tree4S, date=as.numeric(totime[,2]),rate=rate)
rootDate<-newtree4S$rootdate
Ntree4S<-newtree4S$tree

colorSub<-c( "dodgerblue4", "deeppink" , "forestgreen","orange", "gold", "firebrick2","dodgerblue4", "lightpink", "mistyrose3","lightseagreen","lightsalmon","mediumorchid","mediumpurple4","olivedrab2", "grey60")

 subgroup<-Ntree4S$tip.label
individuals<-sapply(1:length(subgroup), function(x) unlist(strsplit(subgroup[x],"_"))[1])
if(length(unique(individuals))>1){
colSub<-sapply(1:length(individuals), function(x) colorSub[which(unique(individuals)==individuals[x])])
}

plot.phylo(Ntree4S,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axisPhylo(side=1,root.time=rootDate, backward=FALSE)
 
plot.phylo(Ntree4S,tip.color=colSub, edge.width = 2, font = 2 , cex=0.7,align.tip.label=TRUE)
 axis(side=1,  at=c(-0.02,0.15,0.4,0.64,0.89),label=c("10Apr","1Jul2007","1Oct2007","1Jan2008","1Apr2008"),lwd=2)

